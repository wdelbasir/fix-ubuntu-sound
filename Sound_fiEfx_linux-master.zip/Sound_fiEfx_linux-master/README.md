# Sound_fiEfx_linux
Sound_fiEfx_linux is a set of commands that fixes the no sound issue, on most of the Linux distros.  Easy to install list based commands. Created by Tech EFX Tv.

There is a list of commands we have combined in the bash file is listed below.
# sudo apt-get remove alsa-base pulseaudio
# sudo apt-get install alsa-base pulseaudio
# sudo alsa force-reload 
# alsamixer
# sudo apt install pavucontrol
# pavucontrol
# clean
# exit

These commands removes the default sound PulseAudio and reinstall it to get the audio. Another application Pavucontrol allows you to boost the sound 200%.

How to run this application
===========================
git clone https://github.com/efxtv/Sound_fiEfx_linux.git

chmod 777 Sound_fiEfx_linux.sh

./Sound_fiEfx_linux.sh

---------------------------------------
India :  7503453371@ybl<br />
<a href="https://paypal.me/efxtv"><img src="https://raw.githubusercontent.com/efxtv/efxtv/master/assets/donate-efx-tv.png" alt="Paypal" width="125" height="40"></a>
---------------------------------------
